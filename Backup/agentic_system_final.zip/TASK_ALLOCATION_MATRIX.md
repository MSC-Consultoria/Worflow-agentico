# TASK_ALLOCATION_MATRIX.md

Formal contract.
