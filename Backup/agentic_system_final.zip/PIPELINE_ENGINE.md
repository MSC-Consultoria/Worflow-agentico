# PIPELINE_ENGINE.md

Formal contract.
