# initial_governance_notes.md

Historical document.
