# MEMORY_ARCHITECTURE

Formal memory architecture.
