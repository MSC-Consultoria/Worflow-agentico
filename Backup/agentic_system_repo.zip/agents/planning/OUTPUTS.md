# PLANNING OUTPUTS

Formal version.
