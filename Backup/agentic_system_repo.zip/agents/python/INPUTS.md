# PYTHON INPUTS

Formal version.
