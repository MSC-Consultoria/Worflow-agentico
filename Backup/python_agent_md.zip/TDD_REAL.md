# TDD Real
Regras de TDD bloqueante para o Python Agent.
