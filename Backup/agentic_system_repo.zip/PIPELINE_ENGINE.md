# PIPELINE_ENGINE

Formal pipeline engine.
