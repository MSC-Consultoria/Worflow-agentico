# DECISIONS.md — Decision Log

(See previous message content — English version is source of truth)
