# PLANNING INPUTS

Formal version.
