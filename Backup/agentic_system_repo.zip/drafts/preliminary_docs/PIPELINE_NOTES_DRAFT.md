# PIPELINE_NOTES_DRAFT.md

Preliminary or deprecated document.
