# PYTHON INPUTS

Defined.
