# GITHUB OUTPUTS

Formal version.
