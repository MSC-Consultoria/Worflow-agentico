# GLOSSARY.md

Formal contract.
