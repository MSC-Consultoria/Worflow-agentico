# PYTHON AGENT — EXECUTION PLAYBOOK
(Conteúdo consolidado: Task Types, Context Variability, TDD Rules, Security Hooks, PR Standard)
