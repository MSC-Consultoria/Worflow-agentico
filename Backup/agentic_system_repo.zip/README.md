# Agentic Governance System

## Overview
This repository contains the **formal, governed version** of an agentic system
designed around high-level human governance, Markdown contracts, and Python execution.

GitHub is the source of truth.
Markdown is the durable memory.
Python is the execution layer.

## Architecture Summary
Human → Markdown → Pipeline Engine → Agents → Outputs

## Core Governance Documents
- GLOSSARY.md
- DECISIONS.md
- PROCESS_GUARDRAILS.md
- TASK_ALLOCATION_MATRIX.md
- PIPELINE_ENGINE.md
- PIPELINE_ENGINE_PYTHON_INTERFACE.md
- SECURITY_AND_BENCHMARK_TESTS.md
- MEMORY_ARCHITECTURE.md

## Agents
- Planning / PRD Agent
- Test Creation Agent
- Python Agent
- Security Agent
- GitHub Agent

## Drafts & History
Early drafts and deprecated or exploratory documents are stored under `/drafts`
to preserve system evolution and timeline.

English is the system language.
Portuguese is explanatory.
