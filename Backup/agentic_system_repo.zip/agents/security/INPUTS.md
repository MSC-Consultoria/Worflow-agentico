# SECURITY INPUTS

Formal version.
