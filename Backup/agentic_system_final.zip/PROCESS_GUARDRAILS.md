# PROCESS_GUARDRAILS.md

Formal contract.
