# Context Variability
Definição operacional, regras, exemplos e testes conforme acordado.
