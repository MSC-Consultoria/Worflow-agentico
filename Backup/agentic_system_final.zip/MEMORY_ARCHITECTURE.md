# MEMORY_ARCHITECTURE.md

Formal contract.
