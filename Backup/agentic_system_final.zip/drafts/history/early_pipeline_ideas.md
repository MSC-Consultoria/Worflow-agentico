# early_pipeline_ideas.md

Historical document.
