# Executable Security Checklist
Checklist de segurança executável com gates e testes.
