# TESTS INPUTS

Formal version.
