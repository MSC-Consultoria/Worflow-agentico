# GLOSSARY.md — Operational Glossary

(See previous message content — English version is source of truth)
