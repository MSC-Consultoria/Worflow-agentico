# PLANNING TESTS

Formal version.
