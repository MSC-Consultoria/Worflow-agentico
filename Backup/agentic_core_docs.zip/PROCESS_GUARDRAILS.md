# PROCESS_GUARDRAILS.md — Simplicity, Collaboration & Complexity Checkpoints

## Purpose

This document defines lightweight guardrails to:
- control complexity growth,
- enable collaborative agent behavior,
- preserve incremental evolution.

These rules exist to protect the workflow, not restrict it.

---

## Simplicity Checkpoint

Before starting or merging any relevant task, answer:

> Can this be done in fewer steps?

If the answer is unclear, the task is too large and must be split.

---

## Incremental Evolution Rule

- One objective per step
- One contract per Markdown file
- One decision per PR

Progress is measured by clarity, not volume.

---

## Collaborative Mode

Agents are explicitly allowed to:

- suggest process improvements,
- recommend strategy changes,
- propose simplifications,
- indicate better next steps,
- raise concerns even when tasks succeed.

Collaboration is proactive, not reactive.

---

## Success-Based Suggestions

Agents should provide 1–2 relevant suggestions:
- after task completion,
- even when all tests pass,
- focused on improvement or simplification.

Silence is acceptable only when no meaningful suggestion exists.

---

## Human Authority

- Humans approve intent and direction.
- Agents execute within defined contracts.
- Suggestions do not override human decisions.

---

## Final Rule

If a rule increases friction more than clarity, it must be questioned.
Simplicity always wins.
