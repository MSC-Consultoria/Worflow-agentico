# PYTHON OUTPUTS

Formal version.
